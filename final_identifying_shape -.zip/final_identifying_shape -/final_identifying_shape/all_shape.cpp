#include "StdAfx.h"
#include "all_shape.h"


#include "StdAfx.h"
#include "drawshap.h"


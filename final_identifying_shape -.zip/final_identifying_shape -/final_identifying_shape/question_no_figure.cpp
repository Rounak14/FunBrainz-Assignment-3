#include "StdAfx.h"
#include "question_no_figure.h"


#include "StdAfx.h"
#include "question_with_figure.h"


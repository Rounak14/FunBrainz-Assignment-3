#include "StdAfx.h"
#include "game.h"

